﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @bool
{
    class Program
    {
        static void Main(string[] args)
        {
            bool avocado = false;

            if (avocado)
            {
                Console.WriteLine("우유 6개 사와");
            }
            else
            {
                Console.WriteLine("아보카도만 사와");
            }
        }
    }
}
